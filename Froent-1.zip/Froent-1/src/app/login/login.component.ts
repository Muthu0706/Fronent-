import { Component } from '@angular/core';
import { AdminserviceService } from '../Service/adminservice.service';
import { Login } from '../model/Login';
import { Router } from '@angular/router';
import { LoginService } from '../Service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {



  [x: string]: any;

  login: Login;

  loginlist: Login[] = [];
  Result: any;
  constructor(private service: LoginService, private router: Router) {


    this.login = new Login();
    this.getAllLoginUser();

  }
  ngOnInit(): void {

  }
  myFunction(data: any) {
    alert("success");

  }


  Logindata(data: any) {

    this.login.username = data.username;
    this.login.password = data.password;
    this.Result = this.service.logindata(this.login);
    this.getAllLoginUser();
  }
  getAllLoginUser() {
    this.service.getAllLoginUser().subscribe((loginuser: Login[]) => this.loginlist = loginuser);
  }
}



function goToList() {
  throw new Error('Function not implemented.');
}

