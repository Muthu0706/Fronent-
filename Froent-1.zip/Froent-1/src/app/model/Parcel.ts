import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
// export class User {
//     id!:number;
//     username!: String;
//     email!: String;
//     address!: String;
//     phoneNumber!: String;
//     password!: String;
// }
export class Parcel{
    recipientName!:String;
    fromAddress!: String;
    recipientAddress!: String;
    parcelName!: String;
    recipientPhoneNumber!: number;
    // productImage!:String;
    // status!:String;
    weight!:number;
}
// export class CourierStaff {
//     staffName!: String;
//     PhoneNumber!: number;
// } 
// export class UserService {
//     register(value: any) {
//       throw new Error('Method not implemented.');
//     }
//     username!: String;

//     setuserName(name: String) {
//         this.username = name;
//     }
// }



