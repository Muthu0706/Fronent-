import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
export class Parcel{
    recipientName!:String;
    fromAddress!: String;
    recipientAddress!: String;
    parcelName!: String;
    recipientPhoneNumber!: number;
    productImage!:String;
    status!:String;
    weight!:number;
}
// export class CourierStaff {
//     staffName!: String;
//     phoneNumber!: String;
// } 
// export class UserService {
//     register(value: any) {
//       throw new Error('Method not implemented.');
//     }
//     username!: String;

//     setuserName(name: String) {
//         this.username = name;
//     }
// }



