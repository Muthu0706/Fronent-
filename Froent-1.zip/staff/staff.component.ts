import { Component } from '@angular/core';
import { CourierStaff } from '../model/CourierStaff';
import { StaffService } from '../Service/staff.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent {

  [x: string]: any;

  courierStaff: CourierStaff ;
  result: String = "";
  stafflist: CourierStaff[] = [];

  constructor(private service: StaffService,private router:Router) {


    this.courierStaff = new CourierStaff();
    this.getAllStaff();

  }
  ngOnInit(): void {

  }
  myFunction(data: any) {
    alert("success");

  }

  // SaveCourierStaff(){
  //   this.staffService.Staff(this.courierStaff).subscribe(data =>){
  //     console.log(data);
  //     this.goAllStaffNames();

  //   }
  //   goToList(){
  //     this.router.navigate(['/Admin'])
  //   } 
  //   onsubmit(){
  //     console.log(this.courierStaff);
  //     this.SaveCourierStaff();
  //   }
  // }
  AddCourierStaff(data: any) {

    this.courierStaff.staffName = data.staffname;
    this.courierStaff.phoneNumber = data.phoneNumber;
    this.result = this.service.addCourierStaff(this.courierStaff);
    this.getAllStaff();
  }
  getAllStaff() {
    this.service.getAllStaff().subscribe((staff: CourierStaff[]) => this.stafflist = staff);
  }
}
function goToList() {
  throw new Error('Function not implemented.');
}

