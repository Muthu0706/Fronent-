import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CourierStaff } from '../model/CourierStaff';

@Injectable({
  providedIn: 'root'
})
export class StaffService{
  
  [x: string]: any;

  private url:string = "http://localhost:8976";
  constructor(private http: HttpClient) {
  }
  addCourierStaff(courierStaff : CourierStaff){
      this.http.post(this.url+"/api/admin/courier-staff/add",courierStaff).subscribe();
      return "Record Inserted";
    }
    // deletestaff(satff: Staff) {
    //   this.http.delete(this.url+"//PerformDelete"+Staff).subscribe();
    //   return "Record Deleted";
    // }
    getAllStaff(){
     return this.http.get<CourierStaff[]>(this.url+"/findAll");
    }
   }

