import { Component, OnInit } from '@angular/core';
import { User } from '../model/User';
import { AdminserviceService } from '../Service/adminservice.service';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent{

 
  user: User;
  result: string = "";
  cmslist: User[] = [];
  [x: string]: any;
  constructor(private service: AdminserviceService) {
    this.user = new User();
    this['getAllRegister']();

  }
  ngOnInit(): void {
    
    this['service']['Register']();
  }
  myFunction(_data: any) {
    alert("success");

  }
  
  Register(data: User) {
    this.user.id = data.id;
    this.user.username = data.username;
    this.user.email = data.email;
    this.user.address = data.address;
    this.user.phoneNumber = data.phoneNumber;
    this.user.password = data.password;

    this.result = this['service']['register'](this.user);
    this.getAllRegister();
  }
    Update(data: User) {
      this.user.id = data.id;
      this.user.username = data.username;
      this.user.email = data.email;
      this.user.address = data.address;
      this.user.phoneNumber = data.phoneNumber;
      this.user.password = data.password;
      this.result = this.service.update(this.user);

      // this.result = this['service']['update'](this.user);
      this.getAllRegister();
  }
  getAllRegister(){
    this.service.getAllRegister().subscribe((user: User[])=>this.cmslist = user);
  }  
}

