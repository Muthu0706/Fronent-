import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Parcel } from '../model/Parcel';

@Injectable({
  providedIn: 'root'
})
export class ParcelService {

  [x: string]: any;
  private url:string = "http://localhost:8976";

  constructor(private http: HttpClient) { 
  }
  addParcel(parcel :Parcel){
    alert("Successfully");
    var msg = this.http.post(this.url+"/api/login/user/parcels/create",parcel).subscribe();
    alert(msg);
    return "Record Inserted";
  }
  // getAllParcel() {
  //   this['service'].getAllParcel().subscribe((parcel: Parcel[]) => this['pmslist'] = parcel);
  // }

 
  

  deleteParcel(parcel: Parcel) {
    this.http.delete(this.url+"/deleted/{uname}"+parcel.recipientName).subscribe();
    return "Record Deleted";
  }
  getAllParcel(){
    return this.http.get<Parcel[]>(this.url+"/api/login/user/parcels/all");
   }
}