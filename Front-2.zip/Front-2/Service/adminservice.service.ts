import { Injectable } from '@angular/core';
import {  User } from '../model/User';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {

  [x: string]: any;
  private url:string = "http://localhost:8976";

  constructor(private http: HttpClient) {
  }
  register(user : User){
    this.http.post(this.url+"/api/register",user).subscribe();
    return "Record Inserted";
  }

  update(user:User ) {
    this.http.put(this.url +"/PerformUpdate",user).subscribe();
    return "Record Updated";
  }

  getAllRegister(){
    return this.http.get<User[]>(this.url+"/viewAll");
   }
  // deletePatient(User: User) {
  //   this.http.delete(this.url+"/PerformDelete/"+patient.patId).subscribe();
  //   return "Record Deleted";
  // }
 
  storeToken(token:string){
      sessionStorage.setItem('token',token);
  }
  login(user:User){
        this.http.post(this.url+"/api/user",user).subscribe();
        return  "Loged";
  } 
  removeToken(){
    sessionStorage.removeItem('token');
  }
  // insertStaff(staff : Staff){
  //   this.http.post(this.url+"/PerformInsert",staff).subscribe();
  //   return "Record Inserted";
  // }
  // updateStaff(staff: Staff) {
  //   this.http.put(this.url + "/PerformUpdate" ,staff).subscribe();
  //   return "Record Updated";
  // }
  // deleteStaff(Staff: Staff) {
  //   this.http.delete(this.url+"/PerformDelete/"+Staff.staffname).subscribe();
  //   return "Record Deleted";
  // }
  // getAllStaff(){
  //  return this.http.get<Staff[]>(this.url+"/viewAll");
  // }
  // getAllRegister(){
  //   return this.http.get<[]>(this.url+"/viewAll");
  //  }
  }




