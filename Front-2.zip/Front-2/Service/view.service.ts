import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ViewService {
  [x: string]: any;
  private url:string = "http://localhost:8976";

  constructor(private http: HttpClient) { 
  }
  // addParcel(parcel :Parcel){
  //   alert("Test");
  //   var msg = this.http.post(this.url+"/api/login/user/parcels/create",parcel).subscribe();
  //   alert(msg);
  //   return "Record Inserted";
  // }
  // getAllParcel() {
  //   this['service'].getAllParcel().subscribe((parcel: Parcel[]) => this['pmslist'] = parcel);
  // }

  // getAllParcel(){
  //   return this.http.get<Parcel[]>(this.url+"/all");
  //  }}
}