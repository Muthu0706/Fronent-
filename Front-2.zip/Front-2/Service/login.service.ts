import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Login } from '../model/Login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  
result:any;


private url: string = "http://localhost:7894";




 constructor(private http: HttpClient) { }
 logindata(login: Login) {
 return this.http.post(this.url + "/api/auth/login", login);

 }
 getAllLoginUser(){
  return this.http.get<Login[]>(this.url+"/findAll");
 }
}
