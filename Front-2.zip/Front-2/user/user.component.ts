import { Component } from '@angular/core';

import { Parcel } from '../model/Parcel';
import { ParcelService } from '../Service/parcel.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {

 

parcel:Parcel;
result:string="";
[x: string]: any;
pmslist: Parcel[] = [];

constructor(private service:ParcelService,private router:Router){
    this.parcel = new Parcel();
    this.getAllParcel();
  }
  ngOnInit() {

  }
  myFunction(_data: any) {
    alert("success");

  }
AddParcel(data:any){
this.parcel.recipientName=data.recipientName;
this.parcel.fromAddress=data.fromAddress;
this.parcel.recipientAddress=data.recipientAddress; 
this.parcel.parcelName=data.parcelName;
this.parcel.recipientPhoneNumber=data.recipientPhoneNumber;
this.parcel.weight=data.weight;
this.result = this.service.addParcel(this.parcel);
this.getAllParcel();
}

DeleteParcel(data:any){
  this.parcel.recipientName=data.recipientName;
  this.parcel.fromAddress=data.fromAddress;
  this.parcel.recipientAddress=data.recipientAddress; 
  this.parcel.parcelName=data.parcelName;
  this.parcel.recipientPhoneNumber=data.recipientPhoneNumber;
  this.parcel.weight=data.weight;
  this.result = this.service.deleteParcel(this.parcel);
  this.getAllParcel();
  }
getAllParcel() {
  this.service.getAllParcel().subscribe((parcel: Parcel[])=>this.pmslist = parcel);

}
}
